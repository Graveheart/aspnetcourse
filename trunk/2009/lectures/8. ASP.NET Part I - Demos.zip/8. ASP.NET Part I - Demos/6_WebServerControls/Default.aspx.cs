﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        this.lblErrors.Text = String.Empty;
        if (this.CalendarFrom.SelectedDate > this.CalendarTo.SelectedDate)
        {
            this.lblErrors.Text = "Invalid date interval!";
            return;
        }
        
        if (this.txtSearch.Text.ToUpper().Contains("CHUCK NORRIS"))
        {
            this.litResults.Text = "You cannot search for Chuck Norris because you don't find Chuck Norris, he finds you";
            return;
        }

        this.litResults.Text = "No results found";
    }
    protected void lnkBtnPickFrom_Click(object sender, EventArgs e)
    {
        this.CalendarFrom.Visible = true;
        this.lnkBtnPickFrom.Visible = false;

        this.lblDateFrom.Text = "Date From:";
    }
    protected void lnkBtnPickTo_Click(object sender, EventArgs e)
    {
        this.CalendarTo.Visible = true;
        this.lnkBtnPickTo.Visible = false;

        this.lblDateTo.Text = "Date To:";
    }

    protected void CalendarFrom_SelectionChanged(object sender, EventArgs e)
    {
        this.CalendarFrom.Visible = false;
        this.lnkBtnPickFrom.Visible = true;

        this.lblDateFrom.Text += this.CalendarFrom.SelectedDate.ToShortDateString();
    }

    protected void CalendarTo_SelectionChanged(object sender, EventArgs e)
    {
        this.CalendarTo.Visible = false;
        this.lnkBtnPickTo.Visible = true;

        this.lblDateTo.Text += this.CalendarTo.SelectedDate.ToShortDateString();
    }
}