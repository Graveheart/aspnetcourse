using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;

public partial class _Default : System.Web.UI.Page 
{
    StringBuilder sb = new StringBuilder();
    protected override void OnPreInit(EventArgs e)
    {
        sb.AppendLine("PreInit<br/>");
        base.OnPreInit(e);
    }

    protected override void OnInit(EventArgs e)
    {
        sb.AppendLine("Init<br/>");
        base.OnInit(e);
    }

    protected override void OnInitComplete(EventArgs e)
    {
        sb.AppendLine("InitComplete<br/>");
        base.OnInitComplete(e);
    }

    protected override void OnPreLoad(EventArgs e)
    {
        sb.AppendLine("PreLoad<br/>");
        base.OnPreLoad(e);
    }

    protected override void OnLoad(EventArgs e)
    {
        sb.AppendLine("Load<br/>");
        base.OnLoad(e);
    }

    protected override void OnLoadComplete(EventArgs e)
    {
        sb.AppendLine("LoadComplete<br/>");
        base.OnLoadComplete(e);
    }

    protected override void OnPreRender(EventArgs e)
    {
        sb.AppendLine("PreRender<br/>");
        base.OnPreRender(e);
    }

    protected override void Render(HtmlTextWriter writer)
    {
        sb.AppendLine("Render<br/>");

        Response.Clear();
        writer.WriteLine(sb.ToString());
        Response.End();
        Response.Flush();
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

}
