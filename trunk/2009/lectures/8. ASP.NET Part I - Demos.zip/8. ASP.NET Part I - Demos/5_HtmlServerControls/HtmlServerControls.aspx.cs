using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Demo_1_Html_ServerControls_HtmlServerControls : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void SubmitButton_Click(Object sender, EventArgs e)
    {
        if (this.txtSearchField.Value.ToUpper().Contains("CHUCK NORRIS"))
        {
            this.lblResutls.InnerText = "You cannot search for Chuck Norris because you don't find Chuck Norris, he finds you";
        }
        else
        {
            this.lblResutls.InnerText = "No results found";
        }
    }
}