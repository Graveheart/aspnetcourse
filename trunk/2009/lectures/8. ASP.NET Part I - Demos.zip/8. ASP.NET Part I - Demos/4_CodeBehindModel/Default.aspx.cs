﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            Response.Write("<h2>This is your first opnening of the page</h2>");
        }
        else
        {
            Response.Write("<h3>You already opened the page, i.e. it is a postback</h3>");
        }
    }
}