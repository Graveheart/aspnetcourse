﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        List<Product> prList = new List<Product>();

        for (int i = 0; i < 10; i++)
        {
            Product pr = new Product();
            pr.ID = i;
            pr.Name = "TestName_" + i.ToString();
            pr.InStock = (i == 3 || i == 7 || i == 9);

            pr.ImgURL = "http://www.ourtest.org/products/img" + i.ToString();

            prList.Add(pr);
        }

        this.GridView1.DataSource = prList;
        this.GridView1.DataBind();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }
}