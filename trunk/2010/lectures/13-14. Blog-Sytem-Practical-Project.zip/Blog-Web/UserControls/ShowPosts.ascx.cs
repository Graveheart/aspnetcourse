﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Blog_Data;

namespace Blog_System.UserControls
{
    public partial class ShowPosts : System.Web.UI.UserControl
    {
        public IEnumerable<Message> Messages { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            this.RepeaterMessages.DataSource = this.Messages;
            this.RepeaterMessages.DataBind();
        }

        protected void RepeaterMessages_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            NewComment newCommentUserControl =
                (NewComment)e.Item.FindControl("NewComment");
            newCommentUserControl.Visible = !newCommentUserControl.Visible;
        }

        protected void RepeaterMessages_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Message currentMessage = (Message) e.Item.DataItem;
            ShowComments showCommentsUserControl = 
                (ShowComments) e.Item.FindControl("ShowComments");
            showCommentsUserControl.Comments =
                (IEnumerable<Comment>)currentMessage.Comments;
        }
    }
}