﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Blog_Data;

namespace Blog_System.UserControls
{
    public partial class ShowComments : System.Web.UI.UserControl
    {

        public IEnumerable<Comment> Comments { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            this.RepeaterComments.DataSource = this.Comments;
            this.RepeaterComments.DataBind();
        }
        
    }
}