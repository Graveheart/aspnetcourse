﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Blog_Data;

namespace Blog_System
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonSubmit_Click(object sender, EventArgs e)
        {
            BlogDataAccess.CreateMessage(this.TextBoxAuthor.Text,
                DateTime.Now, this.TextBoxTitle.Text, this.TextBoxMessage.Text);

        }
    }
}
