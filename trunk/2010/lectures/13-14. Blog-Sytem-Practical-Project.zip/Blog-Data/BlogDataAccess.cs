﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Blog_Data
{
    public class BlogDataAccess
    {
        public static IEnumerable<Message> GetAllMessages()
        {
            DataClassesBlogDataContext db = new DataClassesBlogDataContext();
            var messages = 
                from msg in db.GetTable<Message>()
                orderby msg.Date descending
                select msg;
            return messages;
        }

        //public static IEnumerable<Comment> GetComments(int msgId)
        //{
        //    DataClassesBlogDataContext db = new DataClassesBlogDataContext();
        //    var comments =
        //        from c in db.GetTable<Comment>()
        //        where c.ID == msgId
        //        select c;
        //    return comments;
        //}

        public static void CreateMessage(string author, DateTime dateTime,
            string title, string body)
        {
            DataClassesBlogDataContext db = new DataClassesBlogDataContext();
            Message msg = new Message()
            {
                Author = author,
                Date = dateTime,
                Title = title,
                Body = body
            };
            db.Messages.InsertOnSubmit(msg);
            db.SubmitChanges();
        }
    }
}
