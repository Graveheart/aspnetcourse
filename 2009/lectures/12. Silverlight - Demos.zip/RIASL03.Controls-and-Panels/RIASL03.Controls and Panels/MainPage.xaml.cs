﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace RIASL03.Controls_and_Panels
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            left = double.NaN;
        }

        double left;
        char op;

        // Event handlers.

        private void LayoutRoot_KeyDown(object sender, KeyEventArgs e)
        {
            // TODO: Handle key presses and call the coresponding commands.
        }

        private void OnDigitClick(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var content = (string)(button.Content);
            this.AddDigit(int.Parse(content));
        }

        private void OnBackspaceClick(object sender, RoutedEventArgs e)
        {
            if (CurrentNumber.Text.Length > 0)
            {
                CurrentNumber.Text = CurrentNumber.Text.Substring(0, CurrentNumber.Text.Length - 1);
            }
        }

        private void OnCEClick(object sender, RoutedEventArgs e)
        {
            this.ClearEntry();
        }

        private void OnOperationClick(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var content = (string)(button.Content);
            this.AddOperation(content[0]);
        }

        private void OnEvaluateClick(object sender, RoutedEventArgs e)
        {
            this.Evaluate();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            HistoryList.Visibility =
                HistoryList.Visibility == System.Windows.Visibility.Visible
                ? System.Windows.Visibility.Collapsed
                : System.Windows.Visibility.Visible;
        }

        private void OnCClick(object sender, RoutedEventArgs e)
        {
            this.Clear();
        }

        private void OnDotClick(object sender, RoutedEventArgs e)
        {
            this.AddDot();
        }

        // Available operations:
        private void AddDigit(int digit)
        {
            if (digit != 0 || CurrentNumber.Text.Length > 0)
            {
                CurrentNumber.Text += digit.ToString();
            }
        }

        private void AddDot()
        {
            if (!CurrentNumber.Text.Contains('.'))
            {
                if (CurrentNumber.Text.Length == 0)
                    CurrentNumber.Text += "0";
                CurrentNumber.Text += ".";
            }
        }

        private void AddOperation(char operation)
        {
            if (double.IsNaN(left))
            {
                left = this.GetNumber();
            }
            else
            {
                var calc =
                    new Calculation(left, this.GetNumber(), op);
                left = calc.Result;
                HistoryList.Items.Add(calc);
            }
            op = operation;
            this.ClearEntry();
            this.UpdateInfo();
        }

        private double GetNumber()
        {
            double result;
            if (double.TryParse(CurrentNumber.Text, out result))
            {
                return result;
            }
            return 0.0;
        }

        private void Evaluate()
        {
            if (!double.IsNaN(left))
            {
                var calc = new Calculation(left, this.GetNumber(), op);
                CurrentNumber.Text = calc.Result.ToString();
                HistoryList.Items.Add(calc);
                this.UpdateInfo();
            }
        }

        private void UpdateInfo()
        {
            if (double.IsNaN(left))
            {
                LeftTextBlock.Text = "";
                OperationTextBlock.Text = "";
            }
            else
            {
                LeftTextBlock.Text = left.ToString();
                OperationTextBlock.Text = op.ToString();
            }
        }

        private void ClearEntry()
        {
            CurrentNumber.Text = string.Empty;
        }

        private void Clear()
        {
            ClearEntry();
            left = double.NaN;
            op = ' ';
            UpdateInfo();
        }
    }
}