﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq.Expressions;
using System.Collections.Generic;

namespace RIASL03.Controls_and_Panels
{
    public class Calculation
    {
        public double LeftSide { get; private set; }
        public char OperationChar { get; private set; }
        public double RightSide { get; private set; }

        public double Result { get { return Calculate(); } }

        private Func<double, double, double> Operation { get; set; }

        private double Calculate()
        {        
            return this.Operation(LeftSide, RightSide);
        }

        private static Dictionary<char, Func<double, double, double>> availableOperations;

        static Calculation()
        {
            availableOperations = new Dictionary<char, Func<double, double, double>>();
            availableOperations.Add('+', (l, r) => l + r);
            availableOperations.Add('-', (l, r) => l - r);
            availableOperations.Add('*', (l, r) => l * r);
            availableOperations.Add(' ', (l, r) => double.NaN);            
        }

        public static Func<double, double, double> GetOperation(char op)
        {
            return availableOperations.ContainsKey(op) ? availableOperations[op] : availableOperations[' '];
        }

        public static bool IsValid(char op)
        {
            return op != ' ' && availableOperations.ContainsKey(op);
        }

        public Calculation(double left, double right, char operationChar)
        {
            LeftSide = left;
            RightSide = right;
            Operation = GetOperation(operationChar);
            OperationChar = IsValid(operationChar) ? operationChar : '?';
        }
    }
}