#region Copyright � 2002 Jean-Claude Manoli [jc@manoli.net]
/*
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author(s) be held liable for any damages arising from
 * the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *   1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software. If you use this software
 *      in a product, an acknowledgment in the product documentation would be
 *      appreciated but is not required.
 * 
 *   2. Altered source versions must be plainly marked as such, and must not
 *      be misrepresented as being the original software.
 * 
 *   3. This notice may not be removed or altered from any source distribution.
 */ 
#endregion

using System;
using System.Collections;
using System.Text.RegularExpressions;


namespace NDoc.VisualStudio
{
	/// <summary>
	/// Represents a Visual Studio c# project file.
	/// </summary>
	public class Project
	{
		internal Project(Solution solution, Guid id, string name)
		{
			_Solution = solution;
			_ID = id;
			_Name = name;
		}

		private Solution _Solution;

		/// <summary>Gets the solution that contains this project.</summary>
		public Solution Solution
		{
			get { return _Solution; }
		}

		private string _RelativePath;

		/// <summary>Gets or sets the relative path (from the solution 
		/// directory) to the project directory.</summary>
		public string RelativePath
		{
			get { return _RelativePath; }
			set { _RelativePath = value; }
		}

		private Guid _ID;

		/// <summary>Gets the GUID that identifies the project.</summary>
		public Guid ID
		{
			get { return _ID; }
		}

		private string _Name;

		/// <summary>Gets the name of the project.</summary>
		public string Name
		{
			get { return _Name; }
		}

		private System.Xml.XmlDocument _ProjectDocument;
        private System.Xml.XPath.XPathNavigator _ProjectNavigator;
        private System.Xml.XmlNamespaceManager _ProjectNamespaceManager;



		/// <summary>Reads the project file from the specified path.</summary>
		/// <param name="path">The path to the project file.</param>
		public void Read(string path)
		{
            System.Xml.XmlDocument _ProjectDocumentLoader = new System.Xml.XmlDocument();
            _ProjectDocument = new System.Xml.XmlDocument();
            _ProjectDocumentLoader.Load(path);
            _ProjectDocument.LoadXml(_ProjectDocumentLoader.InnerXml);
            _ProjectNavigator = _ProjectDocument.CreateNavigator();
            _ProjectNamespaceManager = new System.Xml.XmlNamespaceManager(_ProjectDocument.NameTable);
            _ProjectNamespaceManager.AddNamespace("VS2005", "http://schemas.microsoft.com/developer/msbuild/2003");

//			_ProjectDocument = new System.Xml.XPath.XPathDocument(path);
//			_ProjectNavigator = _ProjectDocument.CreateNavigator();
		}

		/// <summary>Gets a string that represents the type of project.</summary>
		/// <value>"Visual C++" or "C# Local"</value>
		public string ProjectType
		{
			get
			{
				string projectType = "";
				if ((bool)_ProjectNavigator.Evaluate("boolean(VisualStudioProject/@ProjectType='Visual C++')"))
				{
					projectType = "Visual C++";
				}
				else if ((bool)_ProjectNavigator.Evaluate("boolean(VisualStudioProject/CSHARP/@ProjectType='Local')"))
				{
					projectType = "C# Local";
				}
				else if ((bool)_ProjectNavigator.Evaluate("boolean(VisualStudioProject/CSHARP/@ProjectType='Web')"))
				{
					projectType = "C# Web";
				}
                else if ((bool)_ProjectNavigator.Evaluate("boolean(VS2005:Project/VS2005:PropertyGroup/VS2005:ProjectType='Local')", _ProjectNamespaceManager))
                {
                    projectType = "C# Local";
                }
                else if ((bool)_ProjectNavigator.Evaluate("boolean(VS2005:Project/VS2005:PropertyGroup/VS2005:ProjectType='Web')", _ProjectNamespaceManager))
                {
                    projectType = "C# Web";
                }
                else if ((bool)_ProjectNavigator.Evaluate("boolean(VS2005:Project/VS2005:PropertyGroup/VS2005:OutputType='Library')", _ProjectNamespaceManager))
                {
                    projectType = "Library";
                }
				return projectType;
			}
		}

		/// <summary>Gets the name of the assembly this project generates.</summary>
		public string AssemblyName
		{
			get
			{
                if (_ProjectDocument.FirstChild.Name == "Project")
                {
                    return (string)_ProjectNavigator.Evaluate("string(VS2005:Project/VS2005:PropertyGroup/VS2005:AssemblyName)", _ProjectNamespaceManager);
                }
                else
                {
                    return (string)_ProjectNavigator.Evaluate("string(/VisualStudioProject/CSHARP/Build/Settings/@AssemblyName)");
                }
			}
		}

		/// <summary>Gets the output type of the project.</summary>
		/// <value>"Library", "Exe", or "WinExe"</value>
		public string OutputType
		{
			get
			{
                if (_ProjectDocument.FirstChild.Name == "Project")
                {
                    return (string)_ProjectNavigator.Evaluate("string(VS2005:Project/VS2005:PropertyGroup/VS2005:OutputType)", _ProjectNamespaceManager);
                }
                else
                {
                    return (string)_ProjectNavigator.Evaluate("string(/VisualStudioProject/CSHARP/Build/Settings/@OutputType)");
                }
			}
		}

		/// <summary>Gets the filename of the generated assembly.</summary>
		public string OutputFile
		{
			get
			{
				string extension = "";

				switch (OutputType)
				{
					case "Library":
						extension = ".dll";
						break;
					case "Exe":
						extension = ".exe";
						break;
					case "WinExe":
						extension = ".exe";
						break;
				}

				return AssemblyName + extension;
			}
		}

		/// <summary>Gets the default namespace for the project.</summary>
		public string RootNamespace
		{
			get
			{
				return (string)_ProjectNavigator.Evaluate("string(/VisualStudioProject/CSHARP/Build/Settings/@RootNamespace)");
			}
		}

		/// <summary>Gets the configuration with the specified name.</summary>
		/// <param name="configName">A valid configuration name, usually "Debug" or "Release".</param>
		/// <returns>A ProjectConfig object.</returns>
		public IProjectConfig GetConfiguration(string configName)
		{
			System.Xml.XPath.XPathNavigator navigator = null;
            System.Xml.XPath.XPathNodeIterator nodes;
            if (_ProjectDocument.FirstChild.Name == "Project")
            {
                nodes = _ProjectNavigator.Select(string.Format("VS2005:Project/VS2005:PropertyGroup[@Condition=\" '$(Configuration)|$(Platform)' == '{0}|AnyCPU' \"]", configName), _ProjectNamespaceManager);
            }
            else
            {
                nodes = _ProjectNavigator.Select(String.Format("/VisualStudioProject/CSHARP/Build/Settings/Config[@Name='{0}']", configName));
            }
            if (nodes.MoveNext())
			{
				navigator = nodes.Current;
			}
            if (_ProjectDocument.FirstChild.Name == "Project")
            {
                return new ProjectConfig2005(navigator, _ProjectNamespaceManager);

            }
            else
            {
                return new ProjectConfig(navigator);
            }
		}

		/// <summary>Gets the relative path (from the solution directory) to the
		/// assembly this project generates.</summary>
		/// <param name="configName">A valid configuration name, usually "Debug" or "Release".</param>
		public string GetRelativeOutputPathForConfiguration(string configName)
		{
			return System.IO.Path.Combine(
                System.IO.Path.Combine(RelativePath, GetConfiguration(configName).OutputPath), 
				OutputFile);
		}

		/// <summary>Gets the relative path (from the solution directory) to the
		/// XML documentation this project generates.</summary>
		/// <param name="configName">A valid configuration name, usually "Debug" or "Release".</param>
		public string GetRelativePathToDocumentationFile(string configName)
		{
			string path = null;

			string documentationFile = GetConfiguration(configName).DocumentationFile;

			if (documentationFile != null && documentationFile.Length > 0)
			{
                path = System.IO.Path.Combine(RelativePath, documentationFile);
			}

			return path;
		}

	}
}
