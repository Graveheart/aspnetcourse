using System;
using System.Collections.Generic;
using System.Text;

namespace NDoc.VisualStudio
{
    public interface IProjectConfig
    {

        string Name
        { get;}

        string OutputPath
        { get;}

        string DocumentationFile
        { get;}

    }
}
