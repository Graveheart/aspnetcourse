using System;
using System.Collections.Generic;
using System.Text;

namespace NDoc.VisualStudio
{
    /// <summary>
    /// 
    /// </summary>
    internal class ProjectConfig2005: IProjectConfig
    {
		private System.Xml.XPath.XPathNavigator _navigator;
        private System.Xml.XmlNamespaceManager _nameSpaceManager;
        internal ProjectConfig2005(System.Xml.XPath.XPathNavigator navigator, System.Xml.XmlNamespaceManager nameSpaceManager)
		{
            _nameSpaceManager = nameSpaceManager;
            _navigator = navigator.Clone();
		}

        /// <summary>
        /// 
        /// </summary>
        public string Name
        {
            get
            {
                return (string)_navigator.Evaluate("string(VS2005:Name)", _nameSpaceManager);
            }
        }

        /// <summary>Gets the location of the output files (relative to the 
        /// project directory) for this project's configuration.</summary>
        public string OutputPath
        {
            get
            {
                return (string)_navigator.Evaluate("string(VS2005:OutputPath)", _nameSpaceManager);
            }
        }

        /// <summary>Gets the name of the file (relative to the project 
        /// directory) into which documentation comments will be 
        /// processed.</summary>
        public string DocumentationFile
        {
            get
            {
                return (string)_navigator.Evaluate("string(VS2005:DocumentationFile)", _nameSpaceManager);
            }
        }

    }
}
