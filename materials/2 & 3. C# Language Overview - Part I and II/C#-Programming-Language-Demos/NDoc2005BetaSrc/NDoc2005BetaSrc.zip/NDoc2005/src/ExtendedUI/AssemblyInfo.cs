using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("NDoc EntendedUI")]
[assembly: AssemblyDescription("UI Extensions for NDoc")]

#if (OFFICIAL_RELEASE)
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("NDoc.snk")]
[assembly: AssemblyKeyName("")]
#endif
