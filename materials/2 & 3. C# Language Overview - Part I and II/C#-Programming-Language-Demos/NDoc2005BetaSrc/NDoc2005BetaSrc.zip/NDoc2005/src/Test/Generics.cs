using System;
using System.Collections.Generic;
using System.Text;

namespace GenericsTest
{
    /// <summary>
    /// Test app class
    /// </summary>
    public class Generics
    {
        /// <summary>
        /// List&lt;T&gt; test
        /// </summary>
        /// <param name="position"></param>
        /// <param name="list"></param>
        /// <returns></returns>
        public List<string> GenericStringTest(int position, List<string> list)
        {
            return list;
        }

        /// <summary>
        /// Comparer&lt;T&gt; test
        /// </summary>
        /// <param name="T"></param>
        public void ComparerTest(Comparer<string> T)
        {
        }

        /// <summary>
        /// Dictionary&lt;T&gt; test
        /// </summary>
        /// <param name="test"></param>
        public void DictionaryTest(Dictionary<string, string> test)
        {
        }

        /// <summary>
        /// Dictionary&lt;T&gt;.KeyCollection test
        /// </summary>
        /// <param name="collect"></param>
        public void DictionaryKeyCollectionTest(System.Collections.Generic.Dictionary<string, string>.KeyCollection collect)
        {
        }

        /// <summary>
        /// Dictionary&lt;T&gt;.ValueCollection test
        /// </summary>
        /// <param name="collect"></param>
        public void DictionaryKeyCollectionTest(System.Collections.Generic.Dictionary<string, string>.ValueCollection collect)
        {
        }
        /// <summary>
        /// EqualityComparer&lt;T&gt; test
        /// </summary>
        /// <param name="test"></param>
        public void TestEqualityComparer(EqualityComparer<string> test)
        {
        }

        /// <summary>
        /// LinkedList&lt;T&gt; test
        /// </summary>
        /// <param name="list"></param>
        public void TestLinkedList(LinkedList<string> list)
        {
        }

        /// <summary>
        /// LinkedListNode&lt;T&gt; test
        /// </summary>
        /// <param name="node"></param>
        public void TestLinkedListNode(LinkedListNode<string> node)
        {
        }

        /// <summary>
        /// Queue&lt;T&gt; test
        /// </summary>
        /// <param name="queue"></param>
        public void TestQueue(Queue<string> queue)
        {
        }

        /// <summary>
        /// SortedDictionary&lt;T&gt; test
        /// </summary>
        /// <param name="dict"></param>
        public void TestSd(SortedDictionary<string, string> dict)
        {
        }

        /// <summary>
        /// SortedDictionary&lt;T&gt;.KeyCollection test
        /// </summary>
        /// <param name="key"></param>
        public void TestSdK(SortedDictionary<string, string>.KeyCollection key)
        {
        }

        /// <summary>
        /// SortedDictionary&lt;T&gt;.ValueCollection test
        /// </summary>
        /// <param name="value"></param>
        public void TestSdV(SortedDictionary<string, string>.ValueCollection value)
        {
        }

        /// <summary>
        /// SortedList&lt;T&gt; test
        /// </summary>
        /// <param name="list"></param>
        public void TestSL(SortedList<string, string> list)
        {
        }

        /// <summary>
        /// Stack&lt;T&gt; test
        /// </summary>
        /// <param name="st"></param>
        public void TestStack(Stack<string> st)
        {
        }

        /// <summary>
        /// ICollection&lt;T&gt; test
        /// </summary>
        /// <param name="col"></param>
        public void TestICollection(ICollection<string> col)
        {
        }

        /// <summary>
        /// IComparer&lt;T&gt; test
        /// </summary>
        /// <param name="comp"></param>
        public void TestIComparer(IComparer<string> comp)
        {
        }

        /// <summary>
        /// IDictionary&lt;T&gt; test
        /// </summary>
        /// <param name="dict"></param>
        public void TestIDictionary(IDictionary<string, string> dict)
        {
        }

        /// <summary>
        /// IEnumerable&lt;T&gt; test
        /// </summary>
        /// <param name="enu"></param>
        public void TestIenum(IEnumerable<string> enu)
        {
        }

        /// <summary>
        /// IEnumerator&lt;T&gt; test
        /// </summary>
        /// <param name="enu"></param>
        public void TestIEnumerator(IEnumerator<string> enu)
        {
        }

        /// <summary>
        /// IEqualityComparer&lt;T&gt; test
        /// </summary>
        /// <param name="comp"></param>
        public void TestIEqualityComparer(IEqualityComparer<string> comp)
        {
        }

        /// <summary>
        /// IList&lt;T&gt; test
        /// </summary>
        /// <param name="list"></param>
        public void TestIList(IList<string> list)
        {
        }

        /// <summary>
        /// Dictionary&lt;T&gt;.Enumerator test
        /// </summary>
        /// <param name="enu"></param>
        public void TestDE(Dictionary<string,string>.Enumerator enu)
        {
        }

        /// <summary>
        /// Dictionary&lt;T&gt;.KeyCollection.Enumerator
        /// </summary>
        /// <param name="ke"></param>
        public void TestDictionaryKeyCollectionEnumerator(Dictionary<string, string>.KeyCollection.Enumerator ke)
        {
        }

        /// <summary>
        /// Dictionary&lt;T&gt;.ValueCollection.Enumerator
        /// </summary>
        /// <param name="ve"></param>
        public void TestDictionaryValueCollectionEnumerator(Dictionary<string, string>.ValueCollection.Enumerator ve)
        {
        }

        /// <summary>
        /// KeyValuePair&lt;T&gt; test
        /// </summary>
        /// <param name="kvp"></param>
        public void TestKeyValuePair(KeyValuePair<string, string> kvp)
        {
        }

        /// <summary>
        /// LinkedList&lt;T&gt;.Enumerator test
        /// </summary>
        /// <param name="enu"></param>
        public void TestLinkedListEnumerator(LinkedList<string>.Enumerator enu)
        {
        }

        /// <summary>
        /// List&lt;T&gt;.Enumerator test
        /// </summary>
        /// <param name="enu"></param>
        public void TestListEnumerator(List<string>.Enumerator enu)
        {
        }

        /// <summary>
        /// Queue&lt;T&gt;.Enumerator test
        /// </summary>
        /// <param name="enu"></param>
        public void TestQueueEnumerator(Queue<string>.Enumerator enu)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="debug"></param>
        public void TestXX(System.Diagnostics.Debug debug)
        {
        }
    }

}
