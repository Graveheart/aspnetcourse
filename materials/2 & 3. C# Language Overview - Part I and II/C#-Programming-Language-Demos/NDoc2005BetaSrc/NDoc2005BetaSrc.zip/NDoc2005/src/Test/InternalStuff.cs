using System;

namespace NDoc.Test.InternalStuff
{
	/// <summary>
	/// Items marked internal
	/// </summary>
	public class NamespaceDoc {}

	internal class InternalClass
	{
		public InternalClass() {}
	}
}
